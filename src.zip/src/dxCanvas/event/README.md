
## 事件名称

### OrbitControls事件
- 控制器变化
- OrbitEvent.CHANGE

### Img事件
- 图像加载事件
- ImgEvent.LOAD

### Group事件
- 添加事件
- ChildEvent.ADD
***
- 移除事件
- ChildEvent.REMOVE