/*
 * @Description: 
 * @Author: ldx
 * @Date: 2024-09-05 17:45:02
 * @LastEditors: ldx
 * @LastEditTime: 2024-09-30 10:09:17
 */
declare module 'uuid'
declare module 'tinycolor2'
declare module 'react-color';
declare module '*.svg?react'